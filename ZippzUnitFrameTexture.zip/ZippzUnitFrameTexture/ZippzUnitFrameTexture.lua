local media = LibStub("LibSharedMedia-3.0")

-- Set your preferred texture here
local newTexture = media:Fetch("statusbar", "Flat") -- Change this to any SharedMedia texture

-- Function to apply textures and colors
local function ApplyCustomTextures(self)
    local unit = self.unit or self:GetParent().unit
    if not unit then return end

    -- Health Bar
    if self.healthbar then
        self.healthbar:SetStatusBarTexture(newTexture)

        -- Apply Class Colors for Players, and Reaction Colors for NPCs
        local _, unitClass = UnitClass(unit)
        local unitReaction = UnitReaction(unit, "player")
        if UnitIsPlayer(unit) and unitClass then
            local color = RAID_CLASS_COLORS[unitClass]
            self.healthbar:SetStatusBarColor(color.r, color.g, color.b)
        elseif unitReaction then
            local color = FACTION_BAR_COLORS[unitReaction]
            self.healthbar:SetStatusBarColor(color.r, color.g, color.b)
        else
            self.healthbar:SetStatusBarColor(0, 1, 0) -- Default Green
        end
    end

    -- Power Bar (Mana, Rage, Energy, etc.)
    if self.manabar then
        self.manabar:SetStatusBarTexture(newTexture)
        local powerType = UnitPowerType(unit)
        local color = PowerBarColor[powerType] or {r = 1, g = 1, b = 1}
        self.manabar:SetStatusBarColor(color.r, color.g, color.b)
    end
end

-- Function to Update All Frames
local function UpdateAllUnitFrames()
    ApplyCustomTextures(PlayerFrame)
    ApplyCustomTextures(TargetFrame)
    ApplyCustomTextures(TargetFrameToT)
    ApplyCustomTextures(FocusFrame)
    ApplyCustomTextures(FocusFrameToT)
    ApplyCustomTextures(PetFrame)
end

-- Hook into Blizzard's Unit Frame Updates
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("UNIT_HEALTH")
f:RegisterEvent("UNIT_POWER_UPDATE")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:RegisterEvent("PLAYER_FOCUS_CHANGED")
f:RegisterEvent("UNIT_PET")

f:SetScript("OnEvent", UpdateAllUnitFrames)
